const firebaseConfig = {
  apiKey: "AIzaSyBXQ3Hd2uQJC5RhOJ0s760KX7PWckKTwcU",
  authDomain: "levelquiz-3ca4d.firebaseapp.com",
  projectId: "levelquiz-3ca4d",
  storageBucket: "levelquiz-3ca4d.firebasestorage.app",
  messagingSenderId: "1017358592092",
  appId: "1:1017358592092:web:0345374a79363f3d0f9e99",
  measurementId: "G-1NXQXNVDZD"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
